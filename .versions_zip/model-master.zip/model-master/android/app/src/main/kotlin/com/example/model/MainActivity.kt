package com.example.model

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
